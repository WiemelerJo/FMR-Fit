from subprocess import call

call(['wolframscript', '-file', '/home/benjamin/Documents/test/test.wls', '/home/benjamin/Documents/test/output/results.csv'])